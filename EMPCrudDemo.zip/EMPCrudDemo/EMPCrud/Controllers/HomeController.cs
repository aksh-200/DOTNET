using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using EMPCrud.Models;
using DAL.Connected;
using Empmodel;


namespace EMPCrud.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Index(string demo)

    {  Console.WriteLine(demo);
       ViewData["data"]=demo;
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }
    public IActionResult ReadEmp()
    {
        List<Employee> employees=DBManager.GetEmployees();
        ViewData["data"]=employees;

        return View();
    }

   [HttpGet]
    public IActionResult InsertEmp()
    {
       

        return View();
    }

    [HttpPost]
     public IActionResult InsertEmp(int id ,string fn , string ln)
    {   Console.WriteLine(id);
    Console.WriteLine(fn);
        bool status = DBManager.Insert(id,fn,ln);

        if(status)
        {   
            return RedirectToAction("ReadEmp");
        }

        return View();
    }

     [HttpPost]
    public IActionResult DeleteEmp(int id)
    {
         Console.WriteLine(id);
     bool status = DBManager.Delete(id);

        if(status)
        {   
            return RedirectToAction("ReadEmp");
        }


        return View();
    }


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
