namespace Empmodel;

public class Employee{
    public int id{get;set;}
     
     public string fname{get;set;}

     public string lname{get;set;}

    
}