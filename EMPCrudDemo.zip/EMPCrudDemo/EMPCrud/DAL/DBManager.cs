namespace DAL.Connected;
using Empmodel;
using MySql.Data.MySqlClient;

public class DBManager{

    
    public static string conString=@"server=192.168.10.150;port=3306;user=dac53; password=welcome;database=dac53";

    public static List<Employee>GetEmployees(){
        List<Employee>employee=new List<Employee>();
          MySqlConnection con=new MySqlConnection();
            con.ConnectionString=conString;
            string query = "SELECT * FROM dotnetemp";


        try{

             MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                con.Open();        
                cmd.CommandText=query;
                MySqlDataReader reader=cmd.ExecuteReader();

                while(reader.Read())
                {
                    int eid=int.Parse(reader["id"].ToString());
                    string efname=reader["fname"].ToString();
                    string elname=reader["lname"].ToString();

                    Employee emp = new Employee{
                        id=eid,
                        fname=efname,
                        lname=elname

                    };
                    employee.Add(emp);


                }

        }

        catch(Exception e){
            Console.WriteLine(e.Message);
        }
        finally{
            con.Close();
        }
        return employee;
    } 



    public static bool Insert(int id,string fname , string lname)
    { 
         bool status = false;
           MySqlConnection con=new MySqlConnection();
            con.ConnectionString=conString;
            string query = "insert into dotnetemp values (@Id ,@Fname,@Lname)";
    //    Console.WriteLine(id);
    //      Console.WriteLine(fname);

            try{


                  MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                con.Open();        
                cmd.CommandText=query;
               cmd.Parameters.AddWithValue("@Id",id);
               cmd.Parameters.AddWithValue("@Fname",fname);
               cmd.Parameters.AddWithValue("@Lname",lname);
                cmd.ExecuteNonQuery();
                status = true;
            }
            catch(Exception e){
                Console.WriteLine(e.Message);
            }
            finally{
                con.Close();
            }



        return status;
    }

   





 public static bool Delete(int id)
    { 
         bool status = false;
           MySqlConnection con=new MySqlConnection();
            con.ConnectionString=conString;
            string query = "delete from dotnetemp where id = " + id;
    //    Console.WriteLine(id);
    //      Console.WriteLine(fname);

            try{


                  MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                con.Open();        
                cmd.CommandText=query;
             
                cmd.ExecuteNonQuery();
                status = true;
            }
            catch(Exception e){
                Console.WriteLine(e.Message);
            }
            finally{
                con.Close();
            }



        return status;
    }

   








   
}