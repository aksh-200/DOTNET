namespace DAL.connected;
using Timesheet;
using MySql.Data.MySqlClient;


public class DBManager{


    public static string conString="server=192.168.10.150; port=3306; user=dac53; password=welcome; database=dac53";       

   public static List<Timesheetmodel> GetAllTimesheet(){
      MySqlConnection con=new MySqlConnection();
            con.ConnectionString=conString;
           

   string query = "select * from timesheet";
   List<Timesheetmodel>alltimesheet = new List<Timesheetmodel>();
  

 try{


 MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                con.Open();        
                cmd.CommandText=query;
                MySqlDataReader reader=cmd.ExecuteReader();

      
       while(reader.Read())
       {
        string  date2 = reader["DATE"].ToString();
        string description = reader["description"].ToString();

        int hours  =int.Parse( reader["hours"].ToString());
        int status1 = int.Parse(reader["status"].ToString());

      string status;
        if(status1 ==0)
        { 
            status = "Incomplete" ;

        }
        else{
             status = "complete";
        }

   
               
                Timesheetmodel timesheet = new Timesheetmodel{date1=date2 ,description=description , hours=hours,status=status};
                alltimesheet.Add(timesheet);
    
       }
      
 }

catch(Exception e){
    Console.WriteLine(e.Message);

}

finally{
    con.Close();
}
 
 return alltimesheet;
 
   }












public static List<Timesheetmodel> GetByDate(string givendate){
      MySqlConnection con=new MySqlConnection();
            con.ConnectionString=conString;
           

   string query = "select * from timesheet where DATE=@Date3";
   List<Timesheetmodel>allworkbydate = new List<Timesheetmodel>();
  

 try{


 MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                con.Open();        
                cmd.CommandText=query;
             cmd.Parameters.AddWithValue("@Date3",givendate);      
                MySqlDataReader reader=cmd.ExecuteReader();

      
       while(reader.Read())
       {
        string  date2 = reader["DATE"].ToString();
        string description = reader["description"].ToString();

        int hours  =int.Parse( reader["hours"].ToString());
        int status1 = int.Parse(reader["status"].ToString());
      string status;
        if(status1 ==0)
        { 
            status = "Incomplete" ;

        }
        else{
             status = "complete";
        }


         Console.WriteLine(date2);
               
                Timesheetmodel timesheet = new Timesheetmodel{date1=date2 ,description=description , hours=hours,status=status};
                allworkbydate.Add(timesheet);
    
       }
      
 }

catch(Exception e){
    Console.WriteLine(e.Message);

}

finally{
    con.Close();
}
 
 return allworkbydate;
 
   }








    public static bool Insert(string date,string desc , int hours , int statusoftable)
    { 
         bool status = false;
           MySqlConnection con=new MySqlConnection();
            con.ConnectionString=conString;
            string query = "insert into timesheet values (@Date ,@Description ,@Hours,@Status)";
  

            try{


                  MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                con.Open();        
                cmd.CommandText=query;
               cmd.Parameters.AddWithValue("@Date",date);
               cmd.Parameters.AddWithValue("@Description",desc);
               cmd.Parameters.AddWithValue("@Hours",hours);
                 cmd.Parameters.AddWithValue("@Status",statusoftable);
                cmd.ExecuteNonQuery();
                status = true;
            }
            catch(Exception e){
                Console.WriteLine(e.Message);
            }
            finally{
                con.Close();
            }



        return status;
    }

   











}