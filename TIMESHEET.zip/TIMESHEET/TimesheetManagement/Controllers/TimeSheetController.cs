using System.Diagnostics;
using DAL.connected;
using Microsoft.AspNetCore.Mvc;
using TimesheetManagement.Models;
using Timesheet;
using  DAL.connected;

namespace TimesheetManagement.Controllers;

public class TimeSheetController : Controller
{
    private readonly ILogger<TimeSheetController> _logger;

    public TimeSheetController(ILogger<TimeSheetController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult GetAllTimeSheet()
    {

        List<Timesheetmodel>alltimesheet = DBManager.GetAllTimesheet();
        ViewData["data"]=alltimesheet;
        Console.WriteLine(alltimesheet);
        return View();
    }
   

   public IActionResult GetDetails(string givendate)
    {

         List<Timesheetmodel>alltimesheet = DBManager.GetByDate(givendate);
        ViewData["data"]=alltimesheet;
        Console.WriteLine(givendate);
        return View();
    }


public IActionResult Insert()
    {

      
        
     
        return View();
    }



[HttpPost]
 public IActionResult Insert(string date, string desc , int hours, int status)
    {

       bool status2 = DBManager.Insert(date,desc,hours,status);
       
        return View();
    }




    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
