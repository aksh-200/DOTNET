namespace Timesheet;

public class Timesheetmodel{


public string date1 {get;set;}

public string description {get;set;}
public int hours  {get;set;}
public string  status {get;set;}
}